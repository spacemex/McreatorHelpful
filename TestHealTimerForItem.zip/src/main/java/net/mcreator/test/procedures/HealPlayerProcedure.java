package net.mcreator.test.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.TextComponent;

import net.mcreator.test.network.TestModVariables;

public class HealPlayerProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (TestModVariables.MapVariables.get(world).bAllowHeal == true) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < (entity instanceof LivingEntity _livEnt
					? _livEnt.getMaxHealth()
					: -1)) {
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth(entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1);
				TestModVariables.MapVariables.get(world).bAllowHeal = false;
				TestModVariables.MapVariables.get(world).syncData(world);
				TestModVariables.MapVariables.get(world).testTimer = 300;
				TestModVariables.MapVariables.get(world).syncData(world);
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("You Have Been Healed!"), (true));
			}
			if (TestModVariables.MapVariables.get(world).bAllowHeal == true && (entity instanceof LivingEntity _livEnt
					? _livEnt.getHealth()
					: -1) >= (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1)) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("You Are Already At Full Health "), (false));
			}
		}
		if (TestModVariables.MapVariables.get(world).bAllowHeal == false) {
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(
						new TextComponent(("You Have: " + TestModVariables.MapVariables.get(world).testTimer + " Ticks Remaining")), (true));
		}
	}
}
